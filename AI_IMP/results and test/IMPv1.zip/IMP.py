import multiprocessing as mp
import sys
import random
from queue import PriorityQueue
import argparse


class Worker(mp.Process):
    def __init__ (self, inQ, outQ):
        super(Worker, self).__init__(target=self.start)
        self.inQ = inQ
        self.outQ = outQ

    def run (self):
        while True:
            task = self.inQ.get()  # 取出任务， 如果队列为空， 这一步会阻塞直到队列有元素
            # x, y = task     # 解析任务
            self.outQ.put(sample())  # 返回结果


def create_worker (num):
    for i in range(num):
        worker.append(Worker(mp.Queue(), mp.Queue()))
        worker[i].start()


def finish_worker ():
    for w in worker:
        w.terminate()


class node:
    def __init__(self, seq):
        self.seq = seq
        self.value = 0
        self.mark = -1

    def __lt__(self, other):
        return other.value < self.value


def create_graph():
    with open(file_name) as file:
        node_num, line_num = file.readline().split(" ")
        node_num = int(node_num)
        line_num = int(line_num)
        graph = []
        nodes = []

        for i in range(0, node_num):
            graph.append([])
            nodes.append(node(i))

        for i in range(0, line_num):
            node_seq, neighbor_seq, weight = file.readline().split(" ")
            node_seq = int(node_seq) - 1
            neighbor_seq = int(neighbor_seq) - 1
            weight = float(weight)
            graph[node_seq].append((neighbor_seq, weight))

    return graph, nodes


def IC(status, Aset):
    count = len(Aset)
    while len(Aset) != 0:
        newAset = []
        for a in Aset:
            for n in graph[a]:
                if not status[n[0]] and random.random() < n[1]:
                    status[n[0]] = True
                    newAset.append(n[0])
        count += len(newAset)
        Aset = newAset
    del Aset
    del status
    return count


def LT(status, Aset, threshold):
    count = len(Aset)
    while len(Aset) != 0:
        newAset = []
        for a in Aset:
            for n in graph[a]:
                if not status[n[0]] and threshold[n[0]][1] >= threshold[n[0]][0]:
                    status[n[0]] = True
                    newAset.append(n[0])
                    for j in graph[n[0]]:
                        threshold[j[0]][1] += j[1]
        count += len(newAset)
        Aset = newAset
    del Aset
    del status
    del threshold
    return count


def sample():
    if model == 'IC':
        return IC(status.copy(), Aset.copy())
    elif model == 'LT':
        threshold = []

        for n in range(0, len(status)):
            threshold.append([random.random(), 0])
            if threshold[n][0] == 0.0 and not status[n]:
                status[n] = True
                Aset.append(n)
        for a in Aset:
            for n in graph[a]:
                if not status[n[0]]:
                    threshold[n[0]][1] += n[1]
        return LT(status, Aset, threshold)


def ISE():
    ISE_sum = 0
    create_worker(worker_num)
    Task = [() for i in range(N)]  # 生成16个随机任务， 每个任务是2个整数， 需要计算两数之和与积
    for i, t in enumerate(Task):
        worker[i % worker_num].inQ.put(t)  # 根据编号取模， 将任务平均分配到子进程上
    ISE_result = []
    for i, t in enumerate(Task):
        ISE_result.append(worker[i % worker_num].outQ.get())  # 用同样的规则取回结果， 如果任务尚未完成，此处会阻塞等待子进程完成任务
    # print('result', result)
    finish_worker()
    for i in range(len(ISE_result)):
        ISE_sum += ISE_result[i]
    return ISE_sum/len(ISE_result)


def set_status():
    for i in range(len(status)):
        status[i] = False
    for i in Aset:
        status[i] = True


if __name__ == '__main__':

    parser = argparse.ArgumentParser()
    parser.add_argument('-i', '--file_name', type=str, default='network.txt')
    parser.add_argument('-k', '--size', type=str, default=5)
    parser.add_argument('-m', '--model', type=str, default='IC')
    parser.add_argument('-t', '--time_limit', type=int, default=60)

    args = parser.parse_args()
    file_name = args.file_name
    size = int(args.size)
    model = args.model
    time_limit = int(args.time_limit)

    worker = []
    worker_num = 8
    graph, nodes = create_graph()
    status = []
    for i in range(len(nodes)):
        # print(len(nodes))
        status.append(False)
    Aset = []
    N = 100

    pq = PriorityQueue()
    for i in range(len(nodes)):
        Aset = [i]
        # print("prepare, {}".format(Aset))
        set_status()
        nodes[i].value = ISE()
        worker = []
        pq.put(nodes[i])

    result = []
    current = pq.get()
    result.append(current.seq)
    max = current.value
    cycle = 2

    while len(result) < size:
        current = pq.get()
        if current.mark == cycle - 1:
            result.append(current.seq)
            max += current.value
        else:
            Aset = result.copy()
            Aset.append(current.seq)
            # print(Aset)
            set_status()
            sum = ISE()
            worker = []
            current.value = sum - max
            current.mark = cycle
            pq.put(current)
        cycle += 1

    for i in result:
        i += 1
        print(i)

    sys.stdout.flush()
