import multiprocessing as mp
import sys
import ISE
import argparse
# import time
import signal


class Worker(mp.Process):
    def __init__(self, inQ, outQ, task_num):
        super(Worker, self).__init__(target=self.start)
        self.inQ = inQ
        self.outQ = outQ
        self.task_num = task_num

    def run(self):
        while True:
            task = self.inQ.get()  # 取出任务， 如果队列为空， 这一步会阻塞直到队列有元素
            q = []
            for i in range(self.task_num):
                current = tempo[task*self.task_num + i]
                if len(graph.nodes[current]) != 0:
                    q.append([current, cal_ise([current]), -1])
            self.outQ.put(q)


def create_worker(num, task_num):
    for i in range(num):
        worker.append(Worker(mp.Queue(), mp.Queue(), task_num))
        worker[i].start()


def finish_worker ():
    for w in worker:
        w.terminate()


def cal_ise(seeds):
    return ISE.run(seeds, N)


def degree_discount(k):
    candidates = []
    degree = []
    ct = []
    for i in range(graph.node_num):
        degree.append(len(graph.nodes[i]))
        ct.append(0)
    for i in range(k):
        u = degree.index(max(degree))
        degree[u] = -1
        candidates.append(u)
        for child, w in graph.nodes[u].items():
            if child not in candidates:
                ct[child] += 1
                degree[child] = degree[child] - 2 * ct[child] - (len(graph.nodes[child]) - ct[child]) * ct[child] * w
    return candidates


def celf():
    pq = []
    if graph.node_num < 200:
        for i in tempo:
            if len(graph.nodes[i]) == 0:
                pq.append([i, 0, -1])
            else:
                pq.append([i, cal_ise([i]), -1])
    else:
        create_worker(worker_num, int(len(tempo) / worker_num))
        Task = [i for i in range(worker_num)]  # 生成16个随机任务， 每个任务是2个整数， 需要计算两数之和与积
        for i, t in enumerate(Task):
            worker[i % worker_num].inQ.put(t)  # 根据编号取模， 将任务平均分配到子进程上
        for w in worker:
            pq += w.outQ.get()
        finish_worker()

    # print("time: {}".format(time.time() - start))
    # sys.stdout.flush()
    pq = sorted(pq, key=lambda x: x[1], reverse=True)

    result = [pq[0][0]]
    max = pq[0][1]
    del pq[0]
    cycle = 2

    while len(result) < size:
        # print("cycle:{}".format(cycle))
        pq = sorted(pq, key=lambda x: x[1], reverse=True)
        if cycle - pq[0][2] <= 1 + k * int(cycle / co):
            result.append(pq[0][0])
            max += pq[0][1]
            del pq[0]
        else:
            pq[0][1] = cal_ise(result + [pq[0][0]]) - max
            pq[0][2] = cycle
        cycle += 1
    # print("cycle:{}".format(cycle))
    return result


def timeout(signum, frame):
    raise TimeoutError


if __name__ == '__main__':

    # start = time.time()

    parser = argparse.ArgumentParser()
    parser.add_argument('-i', '--file_name', type=str, default='network.txt')
    parser.add_argument('-k', '--size', type=str, default=5)
    parser.add_argument('-m', '--model', type=str, default='IC')
    parser.add_argument('-t', '--time_limit', type=int, default=120)

    args = parser.parse_args()
    file_name = args.file_name
    size = int(args.size)
    model = args.model
    time_limit = int(args.time_limit)

    signal.signal(signal.SIGALRM, timeout)
    signal.setitimer(signal.ITIMER_REAL, time_limit-10)

    try:
        worker = []
        worker_num = 8
        graph = ISE.create_graph(file_name)
        ISE.init(graph, model)

        k = 0
        step = 3200
        co = 100
        if graph.node_num < 200:
            if model == 'IC':
                N = 5000
            else:
                N = 1000
        elif size < 30:
            if model == 'IC':
                N = 1000
            else:
                N = 400
                k = 1
        elif model == 'IC':
            step = 1000
            N = 800
            k = 1
            # co = 50
        else:
            step = 400
            N = 400
            k = 1
            co = 50

        if graph.node_num < 100:
            tempo = range(0, graph.node_num)
        else:
            tempo = degree_discount(step)
        # print("time: {}".format(time.time() - start))
        # sys.stdout.flush()
        result = celf()
        signal.setitimer(signal.ITIMER_REAL, 0)
    except TimeoutError:
        # print("timeout")
        result = degree_discount(size)

    for i in result:
        i += 1
        print(i)
    # print("time: {}".format(time.time() - start))
    sys.stdout.flush()
