## TO-DO

 12.09

- [x] improve the efficiency of generating rr set
- [x] Decrease espoid
- [x] Add multi processing

12.10

- [ ] ~~use heap instead of array~~

- [x] avoid repeating creating processes

- [x] avoid repeating calculating F(Si, R)

  Result: can finish e = 0.1 l = 1 in 7.7 s



