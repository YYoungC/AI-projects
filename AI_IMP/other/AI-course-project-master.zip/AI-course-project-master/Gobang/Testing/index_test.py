

t = (1, 1, 1, 0, 1)
print(t.index(2))