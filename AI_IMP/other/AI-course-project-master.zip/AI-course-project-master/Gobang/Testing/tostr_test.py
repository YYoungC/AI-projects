def to_str(array):
    return ''.join(map(str, array))

print(to_str([1, 23, 3]))