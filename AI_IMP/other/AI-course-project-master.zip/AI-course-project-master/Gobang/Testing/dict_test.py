from collections import defaultdict

record = defaultdict(int)

record['1'] += 1
print(record['1'])