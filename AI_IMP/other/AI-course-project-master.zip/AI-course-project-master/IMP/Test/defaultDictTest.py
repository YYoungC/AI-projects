from collections import defaultdict


d = defaultdict(float)
print(d[300])