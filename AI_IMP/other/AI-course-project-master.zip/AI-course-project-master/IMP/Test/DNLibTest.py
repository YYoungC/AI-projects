import networkx as nx
import ndlib.models.epidemics.SIRModel as sir

