import numpy as np


l = np.array([])
l = np.append(l, [1])
print(l)