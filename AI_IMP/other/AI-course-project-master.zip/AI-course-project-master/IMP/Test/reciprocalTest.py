import numpy as np

l = [1, 2, 4, 2]
print(1 / l)