while 2:
    print(1)
